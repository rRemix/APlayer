package remix.myplayer.interfaces;

/**
 * @ClassName
 * @Description
 * @Author Xiaoborui
 * @Date 2016/9/29 10:10
 */
public interface OnUpdateOptionMenuListener {
    void onUpdate(boolean multiShow);
}
