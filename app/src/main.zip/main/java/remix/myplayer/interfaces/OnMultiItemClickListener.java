package remix.myplayer.interfaces;

/**
 * @ClassName
 * @Description
 * @Author Xiaoborui
 * @Date 2016/9/29 10:02
 */
public interface OnMultiItemClickListener {
    void OnAddToPlayingList();
    void OnAddToPlayList();
    void OnDelete();
}
