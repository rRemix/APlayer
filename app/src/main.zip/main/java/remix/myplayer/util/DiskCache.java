package remix.myplayer.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

/**
 * Created by Remix on 2016/6/14.
 */
public class DiskCache {
    private static DiskLruCache mLrcCache;
    private static DiskLruCache mAlbumCache;
    private static DiskLruCache mArtistCache;
    private static Context mContext;

    public static void init(Context context){
        mContext = context;
        try {
            File lrc_cacheDir = getDiskCacheDir(mContext, "lrc");
            if (!lrc_cacheDir.exists())
                lrc_cacheDir.mkdir();
            mLrcCache = DiskLruCache.open(lrc_cacheDir, getAppVersion(mContext), 1, 2 * 1024 * 1024);

            File thumbnailCacheDir = getDiskCacheDir(mContext,"thumbnail");
            if(!thumbnailCacheDir.exists()){
                if(!thumbnailCacheDir.mkdir()){
                    Toast.makeText(mContext,"创建缓存目录失败",Toast.LENGTH_SHORT).show();
                }
            }

//            File album_cacheDir = getDiskCacheDir(mContext,"thumbnail/album");
//            if(!album_cacheDir.exists())
//                album_cacheDir.mkdir();
//            mAlbumCache = DiskLruCache.open(album_cacheDir,getAppVersion(mContext),1,10 * 1024 * 1024);
//
//            File artist_cacheDir = getDiskCacheDir(mContext,"thumbnail/artist");
//            if(!artist_cacheDir.exists())
//                artist_cacheDir.mkdir();
//            mAlbumCache = DiskLruCache.open(album_cacheDir,getAppVersion(mContext),1,10 * 1024 * 1024);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static DiskLruCache getLrcDiskCache(){
        return mLrcCache;
    }

    public static DiskLruCache getAlbumDiskCache(){return mAlbumCache;}

    public static DiskLruCache getArtistCache(){return mArtistCache;}

    public static File getDiskCacheDir(Context context, String uniqueName) {
        String cachePath;
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())
                || !Environment.isExternalStorageRemovable()) {
            cachePath = context.getExternalCacheDir().getPath();
        } else {
            cachePath = context.getCacheDir().getPath();
        }
        return new File(cachePath + File.separator + uniqueName);
    }

    public static int getAppVersion(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return info.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return 1;
    }

}
