package remix.myplayer.util;

/**
 * Created by taeja on 16-4-15.
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import remix.myplayer.model.PlayListItem;

/**
 * 一些全局变量
 */
public class Global {
    /**
     * 当前正在设置封面的专辑或艺术家id
     */
    public static int mAlbumArtistID = 0;

    /**
     * 当前正在设置封面的专辑或艺术家名字
     */
    public static String mAlbumArtistName = "";

    /**
     * 当前正在设置的是专辑还是艺术家封面
     * 1:专辑 2:艺术家
     */
    public static int mAlbunOrArtist = 1;

    /**
     * 是否开启字母索引
     */
    public static boolean mIndexOpen = false;

    /**
     * 操作类型
     */
    public static int mOperation = -1;
    /**
     * 所有歌曲id
     */
    public static ArrayList<Integer> mAllSongList = new ArrayList<>();
    /**
     * 正在播放歌曲id
     */
    public static ArrayList<Integer> mPlayingList = new ArrayList<>();
    /**
     * 文件夹名与对应的所有歌曲id
     */
    public static Map<String,ArrayList<Integer>> mFolderMap = new HashMap<>();
    /**
     * 最近添加列表
     */
    public static Map<String,ArrayList<PlayListItem>> mPlaylist = new HashMap<>();

    public static void setOperation(int operation){
        mOperation = operation;
    }
    public static int getOperation(){
        return mOperation;
    }

    /**
     * 耳机是否插入
     */
    private static boolean mIsHeadsetOn = false;
    public static void setHeadsetOn(boolean headsetOn){
        mIsHeadsetOn = headsetOn;
    }
    public static boolean getHeadsetOn(){
        return mIsHeadsetOn;
    }

    /**
     * 通知栏是否显示
     */
    private static boolean mNotifyShowing = false;
    public static void setNotifyShowing(boolean isshow){
        mNotifyShowing = isshow;
    }
    public static boolean isNotifyShowing(){
        return mNotifyShowing;
    }

    /**
     * 设置正在播放列表
     * @param list
     */
    public static void setPlayingList(ArrayList<Integer> list) {
        mPlayingList = (ArrayList<Integer>) list.clone();
        XmlUtil.updatePlayingList();
    }


    /**
     * 添加歌曲到正在播放列表
     * @param list
     */
    public static void AddSongToPlayingList(ArrayList<Integer> list) {
        ArrayList<Integer> songIdlist = new ArrayList<>();
        for (Integer id : list){
            if(!mPlayingList.contains(id))
                songIdlist.add(id);
        }
        mPlayingList.clear();
        mPlayingList = songIdlist;
        XmlUtil.updatePlayingList();
    }

}
